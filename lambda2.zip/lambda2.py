
def lambda_handler(event, context):
    
    import logging
    import boto3
    import re
    LOGGER = logging.getLogger()
    LOGGER.setLevel(logging.INFO)

    
    bucket_name = "code-bucket"
    
    try:
        # Configurar el cliente de S3
        s3_client = boto3.client("s3")
        
        # Obtener el nombre del archivo del evento
        nombre_archivo = event.get("nombre_archivo")
        extension = event.get("extension")
        nombre_archivo = nombre_archivo + extension
        
        if not nombre_archivo:
            return {
                "message": "El evento no contiene el nombre del archivo"
            }
        
        # Obtener el contenido del archivo
        response = s3_client.get_object(Bucket=bucket_name, Key=nombre_archivo)
        file_content = response["Body"].read().decode("utf-8")
                
        
        code_metrics = count_lines_of_code_metrics(file_content, extension)

        return code_metrics
    except Exception as e:
        LOGGER.error(f"Error en la función Lambda: {str(e)}")
        return {
            "message": "Ha habido un error"
        }

def count_imports(content, extension):
    import re

    if extension == ".py":
        # Contar líneas que contienen importaciones en Python
        return sum(1 for line in content.splitlines() if re.search(r'^\s*import\s|^\s*from\s', line))

    elif extension == ".java":
        # Contar líneas que contienen importaciones en Java
        return sum(1 for line in content.splitlines() if re.search(r'^\s*import\s', line) or re.search(r'^\s*package\s', line))

    elif extension == ".c":
        # Contar líneas que contienen importaciones en C
        return 0  # No hay importaciones en C

    elif extension == ".js":
        # Contar líneas que contienen importaciones en JavaScript
        return sum(1 for line in content.splitlines() if re.search(r'^\s*import\s', line) or re.search(r'^\s*require\s', line))

    else:
        # Agregar lógica para otros lenguajes si es necesario
        return 0

def count_lines_of_code_metrics(content, extension):
    # Dividir el contenido en líneas
    lines = content.splitlines()

    # Inicializar contadores
    total_lines = len(lines)
    empty_lines = sum(1 for line in lines if not line.strip())

    # Contar líneas con caracteres alfanuméricos
    lines_with_characters = sum(1 for line in lines if any(c.isalnum() for c in line))

    # Contar comentarios según la extensión del archivo
    comments = count_comments(content, extension)

    # Contar importaciones según la extensión del archivo
    imports = count_imports(content, extension)

    # Crear un diccionario con las métricas
    metrics = {
        "Total lines": total_lines,
        "Empty lines": empty_lines,
        "Lines with characters": lines_with_characters,
        "Comments": comments,
        "Imports": imports
    }

    return metrics

def count_comments(content, extension):
    import re

    if extension == ".py":
        # Contar líneas que contienen comentarios en Python
        return sum(1 for line in content.splitlines() if re.search(r'\s*#', line) and not is_inside_string(line))

    elif extension == ".java":
        # Contar líneas que contienen comentarios en Java
        return sum(1 for line in content.splitlines() if (re.search(r'\s*//', line) or re.search(r'\s*/\*', line) or re.search(r'\s*\*/', line)) and not is_inside_string(line))

    elif extension == ".c":
        # Contar líneas que contienen comentarios en C
        return sum(1 for line in content.splitlines() if (re.search(r'\s*//', line) or re.search(r'\s*/\*', line) or re.search(r'\s*\*/', line)) and not is_inside_string(line))

    elif extension == ".js":
        # Contar líneas que contienen comentarios en JavaScript
        return sum(1 for line in content.splitlines() if (re.search(r'\s*//', line) or re.search(r'\s*/\*', line) or re.search(r'\s*\*/', line)) and not is_inside_string(line))

    else:
        # Agregar lógica para otros lenguajes si es necesario
        return 0

def is_inside_string(line):
    import re
    # Verificar si los símbolos de comentario están dentro de una cadena de texto
    return re.search(r'(["\']).*?\1.*?#|(["\']).*?\1.*?//|(["\']).*?\1.*?/\*', line) is not None