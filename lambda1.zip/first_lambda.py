# first_lambda.py

import boto3
import os



def first_lambda(event, context):
    
    file_path = event.get("path")
    
    localstack_endpoint = "http://localhost:4566"
    aws_region = "us-east-1"

    s3_client = boto3.client("s3", endpoint_url=localstack_endpoint, region_name=aws_region)

    code_bucket_name = "code-bucket"
        
    try:
        if not os.path.isfile(file_path):
            raise FileNotFoundError(f"El archivo {file_path} no existe.")

        print(f"Subiendo archivo desde la ruta: {file_path}")
        file_name = os.path.basename(file_path)

        # Subir el archivo al bucket "code-bucket" en LocalStack
        with open(file_path, "rb") as data:
            s3_client.upload_fileobj(data, code_bucket_name, file_name)

        cadena = f"Archivo {file_name} subido exitosamente a {code_bucket_name}"
        print(cadena)
        return cadena
    except Exception as e:
        print(f"Error al ejecutar la lambda: {e}")

