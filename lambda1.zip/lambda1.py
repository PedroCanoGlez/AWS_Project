def lambda_handler(event, context):
    import logging

    LOGGER = logging.getLogger()
    LOGGER.setLevel(logging.INFO)
    logging.info("1")
    
    import boto3
    
    bucket_name = "code-bucket"
    
    try:
        # Configurar el cliente de S3
        s3_client = boto3.client("s3")
        response = s3_client.list_objects_v2(Bucket=bucket_name)

        # Extraer los nombres de los archivos
        files = [obj["Key"] for obj in response.get("Contents", [])]

        # Formatear la respuesta
        formatted_response = f"Archivos en el bucket {bucket_name}:\n"
        formatted_response += "\n".join([f"  - {file}" for file in files])

        return formatted_response

    except:
        return {
            "message": "Ha habido un error"
        }