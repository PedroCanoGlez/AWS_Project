import json
import os
import pickle
import zipfile
import boto3
import tensorflow
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
import numpy as np

# Set up S3 client
s3 = boto3.client('s3')

# Specify the S3 bucket and ZIP file name
bucket_name = 'lambdas-bucket'
zip_file_key = 'lambda3.zip'

# Download ZIP file from S3
s3.download_file(bucket_name, zip_file_key, '/tmp/lambda3.zip')

# Extract model and tokenizer from the ZIP file
with zipfile.ZipFile('/tmp/lambda3.zip', 'r') as zip_ref:
    zip_ref.extract('language_model.keras', '/tmp/')
    zip_ref.extract('tokenizer.pkl', '/tmp/')

# Load the model
model = load_model("/tmp/language_model.keras")

# Load the tokenizer
with open("/tmp/tokenizer.pkl", 'rb') as tokenizer_file:
    tokenizer = pickle.load(tokenizer_file)

def lambda_handler(event, context):
    import json
    import os
    import pickle
    import zipfile
    import boto3
    import tensorflow
    from tensorflow.keras.models import load_model
    from tensorflow.keras.preprocessing.text import Tokenizer
    from tensorflow.keras.preprocessing.sequence import pad_sequences
    import numpy as np
    try:
        # Get the seed text from the user input
        user_input = event.get('input', '')
        seed_text = user_input.strip()

        # Generate the next word
        for _ in range(1):  # Adjust the number of words to generate
            # Tokenize the seed text
            token_list = tokenizer.texts_to_sequences([seed_text])[0]
            # Pad the token list
            token_list = pad_sequences([token_list], maxlen=model.input_shape[1], padding='pre')
            # Predict the probabilities for each word
            probabilities = model.predict(token_list, verbose=0)[0]
            # Get the index of the word with the highest probability
            predicted_index = np.argmax(probabilities)
            # Map the index to the word
            predicted_word = ""
            for word, index in tokenizer.word_index.items():
                if index == predicted_index:
                    predicted_word = word
                    break
            # Update the seed text
            seed_text += " " + predicted_word

        # Prepare response
        response = {
            'generated_text': seed_text
        }

        return {
            'statusCode': 200,
            'body': json.dumps(response)
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
